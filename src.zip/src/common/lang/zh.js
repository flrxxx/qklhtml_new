module.exports = {
  language: {
    name: '简体中文'
  },
  phone_deng: '手机号快捷登录',
  login: '登录',
  phone: '请输入手机号',
  codev: '请输入验证码',
  number_pas: '注册或验证码登录',
  login_text: '若您没有账号，在此页面登录将为您自动注册账号',
  yzm: '获取验证码',
  mia_hou: 'S 后获取',
  zh_password: '账号密码登录',
  zh_pass_phone: '请输入手机号',
  zh_pass_password: '请输入密码'
}

module.exports = {
  language: {
    name: 'English'
  },
  phone_deng: 'Quick login',
  login: 'Login',
  phone: 'Please enter your phone number',
  codev: 'Verification code',
  number_pas: 'Register or login with SMS',
  login_text: 'If you do not have an account, login on this page will automatically register your account',
  yzm: 'SMS Code',
  mia_hou: 'S later',
  zh_password: 'Password login',
  zh_pass_phone: 'Please enter your phone number',
  zh_pass_password: 'Please enter your password'
}
